package bioqueue;

import bioqueue.model.Donante;
import bioqueue.model.TipoOrgano;
import bioqueue.model.TipoSangre;
import bioqueue.service.GestorDonantes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests para GestorDonantes: verifica registro, inventario de órganos,
 * búsqueda y eliminación.
 */
class GestorDonantesTest {

    private GestorDonantes gestor;

    private Donante donante(String cedula, String nombre) {
        return new Donante(cedula, nombre, TipoOrgano.CORAZON, TipoSangre.A_POSITIVO);
    }

    @BeforeEach
    void setUp() {
        gestor = new GestorDonantes();
    }

    // Registro

    @Test
    void registrarDonanteAgregaDonanteYOrgano() {
        gestor.registrar(donante("1", "Luis"));
        assertEquals(1, gestor.getDonantes().size());
        assertEquals(1, gestor.getOrganosDisponibles().size());
    }

    @Test
    void registrarVariosDonantesAumentaInventario() {
        gestor.registrar(donante("1", "Luis"));
        gestor.registrar(donante("2", "Ana"));
        assertEquals(2, gestor.getDonantes().size());
        assertEquals(2, gestor.getOrganosDisponibles().size());
    }

    // Búsqueda

    @Test
    void buscarPorCedulaExistente() {
        gestor.registrar(donante("42", "Sofia"));
        Donante encontrado = gestor.buscarPorCedula("42");
        assertNotNull(encontrado);
        assertEquals("Sofia", encontrado.getNombre());
    }

    @Test
    void buscarPorCedulaInexistenteDevuelveNull() {
        gestor.registrar(donante("1", "Luis"));
        assertNull(gestor.buscarPorCedula("999"));
    }

    // Eliminación 

    @Test
    void eliminarDonanteRemoveDonanteYOrgano() {
        gestor.registrar(donante("7", "Maria"));
        Donante eliminado = gestor.eliminarPorCedula("7");
        assertNotNull(eliminado);
        assertEquals(0, gestor.getDonantes().size());
        assertEquals(0, gestor.getOrganosDisponibles().size());
    }

    @Test
    void eliminarCedulaInexistenteDevuelveNull() {
        gestor.registrar(donante("7", "Maria"));
        assertNull(gestor.eliminarPorCedula("000"));
        assertEquals(1, gestor.getDonantes().size()); // no se modificó
    }

    // Retirar órgano

    @Test
    void retirarOrganoReduceInventario() {
        gestor.registrar(donante("3", "Carlos"));
        var organo = gestor.getOrganosDisponibles().get(0);
        gestor.retirarOrgano(organo);
        assertEquals(0, gestor.getOrganosDisponibles().size());
    }
}
