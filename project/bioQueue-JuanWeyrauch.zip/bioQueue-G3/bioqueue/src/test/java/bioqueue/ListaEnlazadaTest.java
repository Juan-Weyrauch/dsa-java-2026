package bioqueue;

import bioqueue.structures.ListaEnlazada;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests para ListaEnlazada: verifica inserción, eliminación, acceso y casos borde.
 */
class ListaEnlazadaTest {

    private ListaEnlazada<String> lista;

    @BeforeEach
    void setUp() {
        lista = new ListaEnlazada<>();
    }

    // Inserción

    @Test
    void listaInicialmenteVacia() {
        assertTrue(lista.isEmpty());
        assertEquals(0, lista.getSize());
    }

    @Test
    void agregarUnElementoAumentaTamanio() {
        lista.agregar("A");
        assertEquals(1, lista.getSize());
        assertFalse(lista.isEmpty());
    }

    @Test
    void agregarVariosElementosMantieneTamanio() {
        lista.agregar("A");
        lista.agregar("B");
        lista.agregar("C");
        assertEquals(3, lista.getSize());
    }

    @Test
    void agregarNullLanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> lista.agregar(null));
    }

    // Obtener

    @Test
    void obtenerPrimerElemento() {
        lista.agregar("X");
        lista.agregar("Y");
        assertEquals("X", lista.obtener(0));
    }

    @Test
    void obtenerUltimoElemento() {
        lista.agregar("X");
        lista.agregar("Y");
        assertEquals("Y", lista.obtener(1));
    }

    @Test
    void obtenerIndiceNegativoLanzaExcepcion() {
        lista.agregar("A");
        assertThrows(IndexOutOfBoundsException.class, () -> lista.obtener(-1));
    }

    @Test
    void obtenerIndiceFueraDeRangoLanzaExcepcion() {
        lista.agregar("A");
        assertThrows(IndexOutOfBoundsException.class, () -> lista.obtener(1));
    }

    // Eliminar

    @Test
    void eliminarElementoExistenteDevuelveTrue() {
        lista.agregar("A");
        assertTrue(lista.eliminar("A"));
        assertEquals(0, lista.getSize());
    }

    @Test
    void eliminarElementoInexistenteDevuelveFalse() {
        lista.agregar("A");
        assertFalse(lista.eliminar("Z"));
    }

    @Test
    void eliminarCabezaActualizaLista() {
        lista.agregar("A");
        lista.agregar("B");
        lista.eliminar("A");
        assertEquals("B", lista.obtener(0));
    }

    @Test
    void eliminarEnListaVaciaDevuelveFalse() {
        assertFalse(lista.eliminar("X"));
    }
}
