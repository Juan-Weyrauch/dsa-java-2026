package bioqueue;

import bioqueue.structures.PilaHistorial;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests para PilaHistorial: verifica comportamiento LIFO, casos borde y excepciones.
 */
class PilaHistorialTest {

    private PilaHistorial<String> pila;

    @BeforeEach
    void setUp() {
        pila = new PilaHistorial<>();
    }

    // Estado inicial 

    @Test
    void pilaInicialmenteVacia() {
        assertTrue(pila.isEmpty());
        assertEquals(0, pila.getSize());
    }

    // Push

    @Test
    void pushAumentaTamanio() {
        pila.push("A");
        assertEquals(1, pila.getSize());
        assertFalse(pila.isEmpty());
    }

    @Test
    void pushNullLanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> pila.push(null));
    }

    // Pop 

    @Test
    void popDevuelveUltimoElementoAgregado() {
        pila.push("primero");
        pila.push("segundo");
        assertEquals("segundo", pila.pop());
    }

    @Test
    void popReduceTamanio() {
        pila.push("A");
        pila.pop();
        assertEquals(0, pila.getSize());
        assertTrue(pila.isEmpty());
    }

    @Test
    void popEnPilaVaciaLanzaExcepcion() {
        assertThrows(NoSuchElementException.class, () -> pila.pop());
    }

    @Test
    void ordenLIFOCorrecto() {
        pila.push("1");
        pila.push("2");
        pila.push("3");
        assertEquals("3", pila.pop());
        assertEquals("2", pila.pop());
        assertEquals("1", pila.pop());
    }

    // Peek

    @Test
    void peekDevuelveTopesinRemover() {
        pila.push("A");
        pila.push("B");
        assertEquals("B", pila.peek());
        assertEquals(2, pila.getSize()); // no se removió
    }

    @Test
    void peekEnPilaVaciaLanzaExcepcion() {
        assertThrows(NoSuchElementException.class, () -> pila.peek());
    }
}
