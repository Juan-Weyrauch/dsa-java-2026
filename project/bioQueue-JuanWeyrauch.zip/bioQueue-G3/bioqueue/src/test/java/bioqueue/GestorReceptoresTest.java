package bioqueue;

import bioqueue.model.Receptor;
import bioqueue.model.TipoOrgano;
import bioqueue.model.TipoSangre;
import bioqueue.service.GestorReceptores;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests para GestorReceptores: verifica inserción ordenada por prioridad,
 * desempate FIFO, búsqueda y eliminación.
 */
class GestorReceptoresTest {

    private GestorReceptores gestor;

    // Helpers para construir receptores rápidamente
    private Receptor receptor(String cedula, String nombre, int prioridad) {
        return new Receptor(cedula, nombre, TipoOrgano.RINON, TipoSangre.O_POSITIVO, prioridad);
    }

    @BeforeEach
    void setUp() {
        gestor = new GestorReceptores();
    }

    // Inserción ordenada 

    @Test
    void registrarUnReceptorQuedaEnLista() {
        Receptor r = receptor("1", "Ana", 80);
        gestor.registrar(r);
        assertEquals(1, gestor.getListaEspera().size());
    }

    @Test
    void receptorMayorPrioridadQuedaPrimero() {
        Receptor rBaja  = receptor("1", "Juan",  50);
        Receptor rAlta  = receptor("2", "Maria", 90);

        gestor.registrar(rBaja);
        gestor.registrar(rAlta);

        LinkedList<Receptor> lista = gestor.getListaEspera();
        assertEquals("Maria", lista.get(0).getNombre());
        assertEquals("Juan",  lista.get(1).getNombre());
    }

    @Test
    void insertarEnOrdenYaOrdenadoMantienePrioridad() {
        Receptor r1 = receptor("1", "A", 90);
        Receptor r2 = receptor("2", "B", 70);
        Receptor r3 = receptor("3", "C", 50);

        gestor.registrar(r1);
        gestor.registrar(r2);
        gestor.registrar(r3);

        LinkedList<Receptor> lista = gestor.getListaEspera();
        assertEquals(90, lista.get(0).getPuntajePrioridad());
        assertEquals(70, lista.get(1).getPuntajePrioridad());
        assertEquals(50, lista.get(2).getPuntajePrioridad());
    }

    /**
     * Desempate FIFO: si dos receptores tienen igual puntaje,
     * el que ingresó primero debe quedar antes en la lista.
     */
    @Test
    void desempatePorFechaDeIngreso() throws InterruptedException {
        Receptor primero = receptor("1", "Primero", 75);
        Thread.sleep(5); // asegura que fechaRegistro sea diferente
        Receptor segundo = receptor("2", "Segundo", 75);

        gestor.registrar(primero);
        gestor.registrar(segundo);

        LinkedList<Receptor> lista = gestor.getListaEspera();
        assertEquals("Primero", lista.get(0).getNombre());
        assertEquals("Segundo", lista.get(1).getNombre());
    }

    // Búsqueda 

    @Test
    void buscarPorCedulaExistente() {
        gestor.registrar(receptor("99", "Carlos", 60));
        Receptor encontrado = gestor.buscarPorCedula("99");
        assertNotNull(encontrado);
        assertEquals("Carlos", encontrado.getNombre());
    }

    @Test
    void buscarPorCedulaInexistenteDevuelveNull() {
        gestor.registrar(receptor("1", "Ana", 80));
        assertNull(gestor.buscarPorCedula("999"));
    }

    // Eliminación

    @Test
    void eliminarPorCedulaExistente() {
        gestor.registrar(receptor("5", "Pedro", 70));
        Receptor eliminado = gestor.eliminarPorCedula("5");
        assertNotNull(eliminado);
        assertEquals(0, gestor.getListaEspera().size());
    }

    @Test
    void eliminarPorCedulaInexistenteDevuelveNull() {
        gestor.registrar(receptor("5", "Pedro", 70));
        assertNull(gestor.eliminarPorCedula("000"));
        assertEquals(1, gestor.getListaEspera().size()); // no se modificó
    }

    @Test
    void registrarNullNoLanzaExcepcionNiModificaLista() {
        gestor.registrar(null);
        assertEquals(0, gestor.getListaEspera().size());
    }
}
