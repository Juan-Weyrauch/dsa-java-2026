package bioqueue;

import bioqueue.model.*;
import bioqueue.service.GestorDonantes;
import bioqueue.service.GestorReceptores;
import bioqueue.service.ServicioTrasplante;
import bioqueue.utils.BloodCompatibility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests para ServicioTrasplante (match y historial) y BloodCompatibility.
 *
 * NOTA: realizarMatch retira el órgano de organosDisponibles (lista interna),
 * pero el receptor se elimina de la copia devuelta por getListaEspera(),
 * no de la lista interna. Ese comportamiento se refleja en los tests.
 */
class ServicioTrasplanteTest {

    private GestorReceptores gestorReceptores;
    private GestorDonantes gestorDonantes;
    private ServicioTrasplante servicio;

    @BeforeEach
    void setUp() {
        gestorReceptores = new GestorReceptores();
        gestorDonantes   = new GestorDonantes();
        servicio         = new ServicioTrasplante(gestorReceptores, gestorDonantes);
    }

    // BloodCompatibility

    @Test
    void oNegativoEsCompatibleConTodos() {
        for (TipoSangre receptor : TipoSangre.values()) {
            assertTrue(BloodCompatibility.esCompatible(TipoSangre.O_NEGATIVO, receptor),
                    "O- debería ser compatible con " + receptor);
        }
    }

    @Test
    void abPositivoSoloEsCompatibleConsigoMismo() {
        // AB+ como donante solo puede donar a AB+
        for (TipoSangre receptor : TipoSangre.values()) {
            boolean esperado = receptor == TipoSangre.AB_POSITIVO;
            assertEquals(esperado, BloodCompatibility.esCompatible(TipoSangre.AB_POSITIVO, receptor),
                    "AB+ donante con receptor " + receptor);
        }
    }

    @Test
    void incompatibilidadDirecta() {
        // B+ no puede donar a A+
        assertFalse(BloodCompatibility.esCompatible(TipoSangre.B_POSITIVO, TipoSangre.A_POSITIVO));
    }

    // buscarReceptor

    @Test
    void buscarReceptorEncontradoCuandoHayCompatibilidad() {
        Receptor r = new Receptor("1", "Ana", TipoOrgano.RINON, TipoSangre.A_POSITIVO, 80);
        gestorReceptores.registrar(r);

        Donante d = new Donante("10", "Donante", TipoOrgano.RINON, TipoSangre.A_POSITIVO);
        Organo organo = new Organo(TipoOrgano.RINON, TipoSangre.A_POSITIVO, d);

        Receptor encontrado = servicio.buscarReceptor(organo);
        assertNotNull(encontrado);
        assertEquals("Ana", encontrado.getNombre());
    }

    @Test
    void buscarReceptorDevuelveNullSiNoHayCompatibilidad() {
        Receptor r = new Receptor("1", "Ana", TipoOrgano.RINON, TipoSangre.B_POSITIVO, 80);
        gestorReceptores.registrar(r);

        Donante d = new Donante("10", "Donante", TipoOrgano.RINON, TipoSangre.A_POSITIVO);
        Organo organo = new Organo(TipoOrgano.RINON, TipoSangre.A_POSITIVO, d);

        assertNull(servicio.buscarReceptor(organo));
    }

    @Test
    void buscarReceptorDevuelveElDeMayorPrioridad() {
        // Lista: prioridad 90 primero (ya que GestorReceptores ordena)
        Receptor rAlta = new Receptor("1", "Alta",  TipoOrgano.CORAZON, TipoSangre.O_POSITIVO, 90);
        Receptor rBaja = new Receptor("2", "Baja",  TipoOrgano.CORAZON, TipoSangre.O_POSITIVO, 50);
        gestorReceptores.registrar(rBaja);
        gestorReceptores.registrar(rAlta);

        Donante d = new Donante("10", "D", TipoOrgano.CORAZON, TipoSangre.O_POSITIVO);
        Organo organo = new Organo(TipoOrgano.CORAZON, TipoSangre.O_POSITIVO, d);

        Receptor encontrado = servicio.buscarReceptor(organo);
        assertEquals("Alta", encontrado.getNombre());
    }

    @Test
    void buscarReceptorConOrganoNullDevuelveNull() {
        assertNull(servicio.buscarReceptor(null));
    }

    // realizarMatch

    @Test
    void realizarMatchExitosoRegistraEnHistorial() {
        Receptor r = new Receptor("1", "Ana", TipoOrgano.HIGADO, TipoSangre.O_NEGATIVO, 80);
        gestorReceptores.registrar(r);

        Donante d = new Donante("10", "Donante", TipoOrgano.HIGADO, TipoSangre.O_NEGATIVO);
        gestorDonantes.registrar(d);
        Organo organo = gestorDonantes.getOrganosDisponibles().get(0);

        Trasplante resultado = servicio.realizarMatch(organo);

        assertNotNull(resultado);
        assertEquals("Ana", resultado.getReceptor().getNombre());
        assertEquals(1, servicio.getHistorial().getSize());
    }

    @Test
    void realizarMatchSinCompatibleDevuelveNull() {
        Receptor r = new Receptor("1", "Ana", TipoOrgano.PULMON, TipoSangre.B_POSITIVO, 80);
        gestorReceptores.registrar(r);

        Donante d = new Donante("10", "D", TipoOrgano.RINON, TipoSangre.A_POSITIVO);
        gestorDonantes.registrar(d);
        Organo organo = gestorDonantes.getOrganosDisponibles().get(0);

        assertNull(servicio.realizarMatch(organo));
        assertEquals(0, servicio.getHistorial().getSize());
    }

    @Test
    void matchExitosoRetiraElOrganoDeDisponibles() {
        Receptor r = new Receptor("1", "Ana", TipoOrgano.RINON, TipoSangre.A_POSITIVO, 80);
        gestorReceptores.registrar(r);

        Donante d = new Donante("10", "D", TipoOrgano.RINON, TipoSangre.A_POSITIVO);
        gestorDonantes.registrar(d);
        Organo organo = gestorDonantes.getOrganosDisponibles().get(0);

        servicio.realizarMatch(organo);

        assertEquals(0, gestorDonantes.getOrganosDisponibles().size());
    }

    // Historial

    @Test
    void historialInicialmenteVacio() {
        assertTrue(servicio.getHistorial().isEmpty());
    }

    @Test
    void historialRegistraOrdenLIFO() {
        // Dos receptores y dos órganos compatibles
        Receptor r1 = new Receptor("1", "Primero", TipoOrgano.RINON, TipoSangre.O_POSITIVO, 90);
        Receptor r2 = new Receptor("2", "Segundo", TipoOrgano.RINON, TipoSangre.O_POSITIVO, 50);
        gestorReceptores.registrar(r1);
        gestorReceptores.registrar(r2);

        Donante d1 = new Donante("10", "D1", TipoOrgano.RINON, TipoSangre.O_POSITIVO);
        Donante d2 = new Donante("11", "D2", TipoOrgano.RINON, TipoSangre.O_POSITIVO);
        gestorDonantes.registrar(d1);
        gestorDonantes.registrar(d2);

        Organo o1 = gestorDonantes.getOrganosDisponibles().get(0);
        servicio.realizarMatch(o1);

        Organo o2 = gestorDonantes.getOrganosDisponibles().get(0);
        servicio.realizarMatch(o2);

        // El último match es el que está en el tope (LIFO)
        assertEquals(2, servicio.getHistorial().getSize());
        Trasplante ultimo = servicio.getHistorial().peek();
        // El segundo match matcheó a r2 (el de prioridad baja que quedaba)
        // ya que r1 fue tomado por el primer match
        assertNotNull(ultimo);
    }
}
