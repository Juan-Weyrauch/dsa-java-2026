package bioqueue.service;

import bioqueue.model.Organo;
import bioqueue.model.Receptor;
import bioqueue.model.Trasplante;
import bioqueue.structures.PilaHistorial;
import java.time.LocalDateTime;

/**
 * Servicio central que orquesta el proceso de matching y trasplante.
 */
public class ServicioTrasplante {

    private final GestorReceptores gestorReceptores;
    private final GestorDonantes gestorDonantes;

    /** Historial de trasplantes realizados (LIFO). */
    private final PilaHistorial<Trasplante> historial;

    /**
     * Crea el servicio conectando los gestores de receptores y donantes.
     */
    public ServicioTrasplante(GestorReceptores gestorReceptores, GestorDonantes gestorDonantes) {
        this.gestorReceptores = gestorReceptores;
        this.gestorDonantes = gestorDonantes;
        this.historial = new PilaHistorial<>();
    }

    /**
     * Busca el receptor compatible de mayor prioridad y, si existe, registra el trasplante.
     *
     * @param organo el órgano disponible para trasplantar
     * @return el Trasplante realizado, o null si no hubo receptor compatible
     */
    public Trasplante realizarMatch(Organo organo) {
        Receptor receptor = buscarReceptor(organo);

        if (receptor != null) {
            Trasplante nuevoTrasplante = new Trasplante(organo, receptor);

            // Registrar en el historial (LIFO)
            historial.push(nuevoTrasplante);

            // Retirar al receptor de la lista de espera
            gestorReceptores.eliminarPorCedula(receptor.getCedula());

            // Retirar el órgano de la lista de disponibles
            gestorDonantes.getOrganosDisponibles().remove(organo);

            return nuevoTrasplante;
        }
        return null;
    }

    /**
     * Recorre la lista de espera y retorna el primer receptor compatible
     * con el órgano dado (el de mayor prioridad, ya que la lista está ordenada).
     *
     * @param organo el órgano a matchear
     * @return el Receptor compatible, o null si no existe ninguno
     */
    public Receptor buscarReceptor(Organo organo) {
        if (organo == null) return null;

        for (Receptor receptor : gestorReceptores.getListaEspera()) {
            if (receptor.getTipoOrganoNecesitado().equals(organo.getTipo()) &&
                    receptor.getTipoSangre().equals(organo.getTipoSangre())) {
                return receptor;
            }
        }
        return null;
    }

    /** Devuelve el historial de trasplantes para consulta o impresión. */
    public PilaHistorial<Trasplante> getHistorial() {
        return historial;
    }

    /**
     * Imprime el historial completo de trasplantes, del más reciente al más antiguo.
     * Usa una pila auxiliar para no destruir el historial original.
     */
    public void imprimirHistorial() {
        // FIX 1: método void → no puede hacer return con valor; usar println
        if (historial.isEmpty()) {
            System.out.println("El historial está vacío.");
            return; // return sin valor sí está permitido en void
        }

        // FIX 2: PilaHistorial no es Iterable → usar pila auxiliar para recorrer
        // sin destruir el historial original
        PilaHistorial<Trasplante> auxiliar = new PilaHistorial<>();

        // Vaciar historial a auxiliar (invierte el orden)
        while (!historial.isEmpty()) {
            auxiliar.push(historial.pop());
        }

        // Imprimir desde auxiliar y restaurar el historial al mismo tiempo
        while (!auxiliar.isEmpty()) {
            Trasplante t = auxiliar.pop();
            System.out.println(t.toString());
            historial.push(t); // restaurar
        }
    }
}