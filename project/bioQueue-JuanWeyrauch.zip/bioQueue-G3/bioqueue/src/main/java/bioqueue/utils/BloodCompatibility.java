package bioqueue.utils;

import bioqueue.model.TipoSangre;

/**
 * Utilidad para verificar compatibilidad de tipos de sangre entre donante y receptor.
 *
 * <p>La compatibilidad se modela como una matriz booleana donde:</p>
 * <ul>
 *   <li>Las <b>filas</b> representan el tipo de sangre del <b>donante</b>.</li>
 *   <li>Las <b>columnas</b> representan el tipo de sangre del <b>receptor</b>.</li>
 * </ul>
 *
 * <p>El índice de cada tipo de sangre corresponde a su posición ordinal en
 * el enum {@link TipoSangre}, por lo que el orden de ese enum no debe modificarse.</p>
 *
 * <p>Ejemplo de uso:</p>
 * <pre>
 *   boolean ok = BloodCompatibility.esCompatible(TipoSangre.O_NEGATIVO, TipoSangre.AB_POSITIVO);
 *   // → true  (O- es donante universal)
 * </pre>
 *
 * <p>Esta clase no puede instanciarse; todos sus métodos son estáticos.</p>
 */
public class BloodCompatibility {

    // Aliases internos para que la matriz sea legible
    private static final boolean T = true;
    private static final boolean F = false;

    /**
     * Matriz de compatibilidad [donante][receptor].
     * El orden de filas y columnas sigue el ordinal de {@link TipoSangre}:
     *   0=O-, 1=O+, 2=A-, 3=A+, 4=B-, 5=B+, 6=AB-, 7=AB+
     */
    //                              O-  O+  A-  A+  B-  B+  AB- AB+
    private static final boolean[][] COMPATIBILIDAD = {
        /* O-  donante */         { T,  T,  T,  T,  T,  T,  T,  T },
        /* O+  donante */         { F,  T,  F,  T,  F,  T,  F,  T },
        /* A-  donante */         { F,  F,  T,  T,  F,  F,  T,  T },
        /* A+  donante */         { F,  F,  F,  T,  F,  F,  F,  T },
        /* B-  donante */         { F,  F,  F,  F,  T,  T,  T,  T },
        /* B+  donante */         { F,  F,  F,  F,  F,  T,  F,  T },
        /* AB- donante */         { F,  F,  F,  F,  F,  F,  T,  T },
        /* AB+ donante */         { F,  F,  F,  F,  F,  F,  F,  T },
    };

    /** Constructor privado: clase de utilidad, no instanciable. */
    private BloodCompatibility() {}

    /**
     * Verifica si un tipo de sangre de donante es compatible con el de un receptor.
     *
     * @param donante   tipo de sangre del donante (fuente del órgano)
     * @param receptor  tipo de sangre del receptor (paciente en espera)
     * @return {@code true} si la transfusión/trasplante es compatible
     */
    public static boolean esCompatible(TipoSangre donante, TipoSangre receptor) {
        return COMPATIBILIDAD[donante.ordinal()][receptor.ordinal()];
    }
}
