package bioqueue.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Representa un trasplante realizado con su organo, receptor y fecha de asignacion.
 *
 * <p>La clase es de solo lectura despues de su creacion, por lo que no expone setters.</p>
 */
public class Trasplante {

    private Organo organo;
    private Receptor receptor;
    private LocalDateTime fechaAsignacion;

    /**
     * Crea un registro de trasplante y asigna automaticamente la fecha actual.
     *
     * @param organo organo asignado en el trasplante
     * @param receptor receptor que recibe el organo
     */
    public Trasplante(Organo organo, Receptor receptor) {
        this.organo = organo;
        this.receptor = receptor;
        this.fechaAsignacion = LocalDateTime.now();
    }

    /**
     * Obtiene el organo asignado en el trasplante.
     *
     * @return organo trasplantado
     */
    public Organo getOrgano() {
        return organo;
    }

    /**
     * Obtiene el receptor del trasplante.
     *
     * @return receptor asignado
     */
    public Receptor getReceptor() {
        return receptor;
    }

    /**
     * Obtiene la fecha y hora en que se registro la asignacion.
     *
     * @return fecha de asignacion del trasplante
     */
    public LocalDateTime getFechaAsignacion() {
        return fechaAsignacion;
    }

    /**
     * Devuelve una representacion en texto del trasplante para historial.
     *
     * @return cadena con receptor, organo, donante y fecha de asignacion
     */
    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        return "Trasplante{receptor='" + receptor.getNombre() +
                "', organo=" + organo.getTipo() +
                ", donante='" + organo.getDonante().getNombre() +
                "', fecha=" + fechaAsignacion.format(fmt) + "}";
    }
}