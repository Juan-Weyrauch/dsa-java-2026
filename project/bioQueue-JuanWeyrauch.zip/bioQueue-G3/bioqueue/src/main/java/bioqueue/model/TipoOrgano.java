package bioqueue.model;

/**
 * Enumera los tipos de organo gestionados por el sistema de trasplantes.
 */
public enum TipoOrgano {
    CORAZON,
    PULMON,
    HIGADO,
    RINON,
    PANCREAS,
    INTESTINO
}