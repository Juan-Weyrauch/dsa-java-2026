package bioqueue.model;

/**
 * Representa a un donante de organos con su informacion basica y datos de compatibilidad.
 */
public class Donante {

    private String cedula;
    private String nombre;
    private TipoOrgano tipoOrgano;
    private TipoSangre tipoSangre;

    /**
     * Crea un nuevo donante con su identificacion, nombre, tipo de organo y tipo de sangre.
     *
     * @param cedula identificacion unica del donante
     * @param nombre nombre del donante
     * @param tipoOrgano tipo de organo disponible para donacion
     * @param tipoSangre tipo de sangre del donante
     */
    public Donante(String cedula, String nombre, TipoOrgano tipoOrgano, TipoSangre tipoSangre) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.tipoOrgano = tipoOrgano;
        this.tipoSangre = tipoSangre;
    }

    /**
     * Obtiene la cedula del donante.
     *
     * @return cedula del donante
     */
    public String getCedula() { return cedula; }

    /**
     * Obtiene el nombre del donante.
     *
     * @return nombre del donante
     */
    public String getNombre() { return nombre; }

    /**
     * Obtiene el tipo de organo que dona.
     *
     * @return tipo de organo del donante
     */
    public TipoOrgano getTipoOrgano() { return tipoOrgano; }

    /**
     * Obtiene el tipo de sangre del donante.
     *
     * @return tipo de sangre del donante
     */
    public TipoSangre getTipoSangre() { return tipoSangre; }

    /**
     * Devuelve una representacion en texto del donante.
     *
     * @return cadena con los datos principales del donante
     */
    @Override
    public String toString() {
        return "Donante{cedula='" + cedula + "', nombre='" + nombre +
               "', organo=" + tipoOrgano + ", sangre=" + tipoSangre + "}";
    }
}