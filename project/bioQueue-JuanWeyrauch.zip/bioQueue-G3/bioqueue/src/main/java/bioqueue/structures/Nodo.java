package bioqueue.structures;

/**
 * Nodo genérico para una lista enlazada simple.
 *
 * <p>Cada nodo guarda un dato de tipo {@code T} y una referencia al siguiente nodo.
 * Es el bloque básico de construcción de {@link ListaEnlazada}.</p>
 *
 * @param <T> tipo del dato almacenado en el nodo
 */
public class Nodo<T> {

    /** Dato almacenado en este nodo. */
    T data;

    /** Referencia al siguiente nodo de la lista, o {@code null} si es el último. */
    Nodo<T> next;

    /**
     * Crea un nodo con el dato dado y sin sucesor.
     *
     * @param dato el valor a almacenar
     */
    public Nodo(T data) {
        this.data = data;
        this.next = null;
    }
}
