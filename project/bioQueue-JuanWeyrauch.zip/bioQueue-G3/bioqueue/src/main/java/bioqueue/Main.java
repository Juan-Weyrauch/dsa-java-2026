package bioqueue;

import bioqueue.model.*;
import bioqueue.service.GestorDonantes;
import bioqueue.service.GestorReceptores;
import bioqueue.service.ServicioTrasplante;

import java.util.Scanner;

public class Main {

    private static final GestorReceptores gestorReceptores = new GestorReceptores();
    private static final GestorDonantes gestorDonantes = new GestorDonantes();
    private static final ServicioTrasplante servicioTrasplante =
            new ServicioTrasplante(gestorReceptores, gestorDonantes);
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        boolean corriendo = true;
        while (corriendo) {
            mostrarMenuPrincipal();
            int opcion = leerEntero("Opción: ");
            switch (opcion) {
                case 1 -> menuReceptores();
                case 2 -> menuDonantes();
                case 3 -> menuMatch();
                case 4 -> servicioTrasplante.imprimirHistorial();
                case 0 -> corriendo = false;
                default -> System.out.println("Opción inválida.");
            }
        }

        System.out.println("Cerrando BioQueue.");
        scanner.close();
    }

    private static void mostrarMenuPrincipal() {
        System.out.println("  1. Gestión de receptores");
        System.out.println("  2. Gestión de donantes");
        System.out.println("  3. Realizar match / trasplante");
        System.out.println("  4. Ver historial de trasplantes");
        System.out.println("  0. Salir");
    }

    private static void menuReceptores() {
        System.out.println("\n-- Receptores --");
        System.out.println("  1. Registrar receptor");
        System.out.println("  2. Buscar receptor por cédula");
        System.out.println("  3. Eliminar receptor por cédula");
        System.out.println("  4. Listar todos los receptores");
        int op = leerEntero("Opción: ");
        switch (op) {
            case 1 -> registrarReceptor();
            case 2 -> buscarReceptor();
            case 3 -> eliminarReceptor();
            case 4 -> gestorReceptores.listarTodos();
            default -> System.out.println("Opción inválida.");
        }
    }

    private static void menuDonantes() {
        System.out.println("\n-- Donantes --");
        System.out.println("  1. Registrar donante");
        System.out.println("  2. Buscar donante por cédula");
        System.out.println("  3. Eliminar donante por cédula");
        System.out.println("  4. Listar donantes");
        System.out.println("  5. Listar órganos disponibles");
        int op = leerEntero("Opción: ");
        switch (op) {
            case 1 -> registrarDonante();
            case 2 -> buscarDonante();
            case 3 -> eliminarDonante();
            case 4 -> gestorDonantes.listarDonantes();
            case 5 -> gestorDonantes.listarOrganosDisponibles();
            default -> System.out.println("Opción inválida.");
        }
    }

    private static void menuMatch() {
        System.out.println("\n-- Realizar Match --");
        System.out.println("  1. Usar órgano disponible existente");
        System.out.println("  2. Ingresar órgano manualmente");
        int op = leerEntero("Opción: ");
        switch (op) {
            case 1 -> matchDesdeDisponibles();
            case 2 -> matchManual();
            default -> System.out.println("Opción inválida.");
        }
    }


    private static void registrarReceptor() {
        System.out.println("\n-- Nuevo Receptor --");
        String cedula   = leerTexto("Cédula        : ");
        String nombre   = leerTexto("Nombre        : ");
        TipoOrgano organo   = elegirTipoOrgano();
        TipoSangre sangre   = elegirTipoSangre();
        int prioridad       = leerEntero("Prioridad (0-100): ");

        gestorReceptores.registrar(new Receptor(cedula, nombre, organo, sangre, prioridad));
        System.out.println("Receptor registrado.");
    }

    private static void buscarReceptor() {
        String cedula = leerTexto("Cédula a buscar: ");
        Receptor r = gestorReceptores.buscarPorCedula(cedula);
        System.out.println(r != null ? r : "Receptor no encontrado.");
    }

    private static void eliminarReceptor() {
        String cedula = leerTexto("Cédula a eliminar: ");
        Receptor r = gestorReceptores.eliminarPorCedula(cedula);
        System.out.println(r != null
                ? "Receptor eliminado: " + r.getNombre()
                : "Receptor no encontrado.");
    }


    private static void registrarDonante() {
        System.out.println("\n Nuevo Donante ");
        String cedula = leerTexto("Cédula : ");
        String nombre = leerTexto("Nombre : ");
        TipoOrgano organo  = elegirTipoOrgano();
        TipoSangre sangre  = elegirTipoSangre();

        gestorDonantes.registrar(new Donante(cedula, nombre, organo, sangre));
        System.out.println("Donante registrado.");
    }

    private static void buscarDonante() {
        String cedula = leerTexto("Cédula a buscar: ");
        Donante d = gestorDonantes.buscarPorCedula(cedula);
        System.out.println(d != null ? d : "Donante no encontrado.");
    }

    private static void eliminarDonante() {
        String cedula = leerTexto("Cédula a eliminar: ");
        Donante d = gestorDonantes.eliminarPorCedula(cedula);
        System.out.println(d != null
                ? "Donante eliminado: " + d.getNombre()
                : " Donante no encontrado.");
    }


    private static void matchDesdeDisponibles() {
        if (gestorDonantes.getOrganosDisponibles().isEmpty()) {
            System.out.println(" No hay órganos disponibles.");
            return;
        }

        for (int i = 0; i < gestorDonantes.getOrganosDisponibles().size(); i++) {
            Organo organo = gestorDonantes.getOrganosDisponibles().get(i);
            Trasplante t = servicioTrasplante.realizarMatch(organo);
            if (t != null) {
                System.out.println(" Trasplante realizado: " + t);
                return;
            }
        }
        System.out.println(" Ningún órgano disponible es compatible con los receptores en espera.");
    }

    private static void matchManual() {
        System.out.println("\n Órgano a trasplantar ");
        String cedula = leerTexto("Cédula donante : ");
        Donante donante = gestorDonantes.buscarPorCedula(cedula);
        if (donante == null) {
            System.out.println("Donante no encontrado. Registrelo primero.");
            return;
        }

        Organo organo = new Organo(donante.getTipoOrgano(), donante.getTipoSangre(), donante);
        Trasplante t = servicioTrasplante.realizarMatch(organo);
        if (t != null) {
            System.out.println(" Trasplante realizado: " + t);
        } else {
            System.out.println(" No se encontró receptor compatible para ese órgano.");
        }
    }


    private static TipoOrgano elegirTipoOrgano() {
        TipoOrgano[] tipos = TipoOrgano.values();
        System.out.println("Tipo de órgano:");
        for (int i = 0; i < tipos.length; i++) {
            System.out.println("  " + i + ". " + tipos[i]);
        }
        int idx = leerEnteroEnRango("Opción: ", 0, tipos.length - 1);
        return tipos[idx];
    }

    private static TipoSangre elegirTipoSangre() {
        TipoSangre[] tipos = TipoSangre.values();
        System.out.println("Tipo de sangre:");
        for (int i = 0; i < tipos.length; i++) {
            System.out.println("  " + i + ". " + tipos[i]);
        }
        int idx = leerEnteroEnRango("Opción: ", 0, tipos.length - 1);
        return tipos[idx];
    }

    private static String leerTexto(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private static int leerEntero(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número válido.");
            }
        }
    }

    private static int leerEnteroEnRango(String prompt, int min, int max) {
        while (true) {
            int val = leerEntero(prompt);
            if (val >= min && val <= max) return val;
            System.out.println("Ingrese un valor entre " + min + " y " + max + ".");
        }
    }
}