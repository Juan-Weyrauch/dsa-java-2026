package bioqueue.model;

/**
 * Tipos de sangre reconocidos por el sistema.
 *
 * <p>El orden de declaración es relevante: el índice ordinal de cada constante
 * se usa como índice en la matriz de compatibilidad de {@link bioqueue.utils.BloodCompatibility},
 * por lo que <b>no debe modificarse</b> sin actualizar dicha matriz.</p>
 *
 * <pre>
 * Índice  Tipo
 *   0     O_NEGATIVO
 *   1     O_POSITIVO
 *   2     A_NEGATIVO
 *   3     A_POSITIVO
 *   4     B_NEGATIVO
 *   5     B_POSITIVO
 *   6     AB_NEGATIVO
 *   7     AB_POSITIVO
 * </pre>
 */
public enum TipoSangre {
    O_NEGATIVO,
    O_POSITIVO,
    A_NEGATIVO,
    A_POSITIVO,
    B_NEGATIVO,
    B_POSITIVO,
    AB_NEGATIVO,
    AB_POSITIVO
}
