package bioqueue.model;

/**
 * Representa un organo donado junto con su tipo, tipo de sangre y donante de origen.
 */
public class Organo {

    private TipoOrgano tipo;
    private TipoSangre tipoSangre;
    private Donante donante; // Referencia al donante de origen

    /**
     * Crea un nuevo organo donado.
     *
     * @param tipo tipo de organo donado
     * @param tipoSangre tipo de sangre asociado al organo
     * @param donante donante del cual proviene el organo
     */
    public Organo(TipoOrgano tipo, TipoSangre tipoSangre, Donante donante) {
        this.tipo = tipo;
        this.tipoSangre = tipoSangre;
        this.donante = donante;
    }

    /**
     * Obtiene el tipo de organo.
     *
     * @return tipo de organo
     */
    public TipoOrgano getTipo() { return tipo; }

    /**
     * Obtiene el tipo de sangre del organo.
     *
     * @return tipo de sangre asociado al organo
     */
    public TipoSangre getTipoSangre() { return tipoSangre; }

    /**
     * Obtiene el donante de origen del organo.
     *
     * @return donante del organo
     */
    public Donante getDonante() { return donante; }

    /**
     * Devuelve una representacion en texto del organo.
     *
     * @return cadena con los datos principales del organo
     */
    @Override
    public String toString() {
        return "Organo{tipo=" + tipo + ", sangre=" + tipoSangre +
               ", donante='" + donante.getNombre() + "'}";
    }
}