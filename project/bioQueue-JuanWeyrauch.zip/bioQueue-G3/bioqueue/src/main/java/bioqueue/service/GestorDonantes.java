package bioqueue.service;

import bioqueue.model.Donante;
import bioqueue.model.Organo;
import bioqueue.model.Receptor;
import bioqueue.model.TipoOrgano;


import java.util.LinkedList;

/**
 * Servicio que gestiona el registro de donantes y el inventario de órganos
 * disponibles.
 */
public class GestorDonantes {

    /** Lista de todos los donantes registrados. */
    private final LinkedList<Donante> donantes;

    /** Lista de órganos disponibles aún no asignados. */
    private final LinkedList<Organo> organosDisponibles;

    /**
     * Crea un gestor con las listas vacías.
     */
    public GestorDonantes() {
        this.donantes = new LinkedList<>();
        this.organosDisponibles = new LinkedList<>();
    }

    /** Devuelve la lista completa de donantes registrados. */
    public LinkedList<Donante> getDonantes() {
        return donantes;
    }

    /** Devuelve la lista de órganos disponibles para consulta o iteración. */
    public LinkedList<Organo> getOrganosDisponibles() {
        return organosDisponibles;
    }

    /** Registra un donante y agrega su órgano a la lista de disponibles. */
    public void registrar(Donante donante) {
        donantes.add(donante);
        Organo organoDonado = new Organo(donante.getTipoOrgano(),donante.getTipoSangre(), donante);
        organosDisponibles.add(organoDonado);
    }

    /** Elimina un donante y su órgano asociado de las listas. */
    public Donante eliminarPorCedula(String cedula) {
        Donante unDonante = buscarPorCedula(cedula);
        if(unDonante != null){
        Organo unOrgano = buscarOrganosDeDonante(unDonante);
        donantes.remove(unDonante);
        if(unOrgano != null){
        organosDisponibles.remove(unOrgano);}
        return unDonante;
        }
        return null;
    }

    /** Busca un donante por su cédula de identidad. */
    public Donante buscarPorCedula(String cedula) {
        for (Donante unDonante : donantes){
            if (unDonante.getCedula().equals(cedula)) {
                return unDonante;
            }
        }
        return null;
    }


    /** Retira un órgano de la lista de disponibles tras un trasplante exitoso. */
    public boolean retirarOrgano(Organo organo) {
        organosDisponibles.remove(organo);
        return true;
    }

    /** Busca en la lista de disponibles el órgano que pertenece al donante dado. */
    private Organo buscarOrganosDeDonante(Donante donante) {
        for(Organo organo : organosDisponibles){
            if(organo.getDonante().equals(donante)){
                return organo;
            }
        }
        return null;
    }

    /** Imprime por consola todos los donantes registrados. */
    public void listarDonantes() {
        for (Donante unDonante : donantes){
            System.out.println(unDonante.toString());
        }
    }

    /** Imprime por consola todos los órganos disponibles. */
    public void listarOrganosDisponibles() {
        for(Organo unOrgano : organosDisponibles){
            System.out.println(unOrgano.toString());
        }
    }
}