package bioqueue.structures;

/**
 * Lista enlazada simple genérica implementada desde cero.
 *
 * <p>
 * Soporta las operaciones básicas de inserción al final, eliminación por
 * posición o por dato, y acceso por índice. Esta clase es la base sobre la que
 * se construyen estructuras más especializadas como {@link ListaEspera}.
 * </p>
 *
 * <p>
 * No depende de ninguna colección de {@code java.util}.
 * </p>
 *
 * @param <T> tipo de los elementos almacenados
 */
public class ListaEnlazada<T> {

    /** Primer nodo de la lista. */
    protected Nodo<T> head;

    /** Cantidad de elementos en la lista. */
    protected int size;

    public ListaEnlazada() {
        head = null;
        size = 0;
    }

    /**
     * Agrega un elemento al final de la lista.
     *
     * @param dato el elemento a agregar; no puede ser {@code null}
     * @throws IllegalArgumentException si el dato es {@code null}
     */
    public void agregar(T dato) {
        if (dato == null) {
            throw new IllegalArgumentException("El dato no puede ser null.");
        }

        Nodo<T> newNodo = new Nodo<>(dato);

        if (head == null) {
            head = newNodo;
        } else {
            Nodo<T> current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNodo;
        }
        size++;
    }

    /**
     * Inserta un nodo ya construido como cabeza de la lista.
     * Usado en subclases para controlar la estructura interna.
     */
    protected void insertarComoNuevaCabeza(Nodo<T> nodo) {
        nodo.next = head;
        head = nodo;
        size++;
    }

    /**
     * Elimina la primera ocurrencia del dato dado, usando {@code equals} para
     * comparar.
     *
     * @param dato el elemento a eliminar
     * @return {@code true} si se encontró y eliminó, {@code false} si no estaba
     */
    public boolean eliminar(T dato) {
        if (head == null) {
            return false;
        }

        // Caso: el nodo a eliminar es la cabeza
        if (head.data.equals(dato)) {
            head = head.next;
            size--;
            return true;
        }

        // Caso general: buscar el nodo anterior al que se quiere eliminar
        Nodo<T> previous = head;
        Nodo<T> current = previous.next;

        while (current != null) {
            if (current.data.equals(dato)) {
                previous.next = current.next;
                size--;
                return true;
            }
            previous = current;
            current = current.next;
        }

        return false;
    }

    /**
     * Devuelve el elemento en la posición indicada (base 0).
     *
     * @param indice índice del elemento
     * @return el elemento en esa posición
     * @throws IndexOutOfBoundsException si el índice está fuera de rango
     */
    public T obtener(int indice) {
        if (indice < 0 || indice >= size) {
            throw new IndexOutOfBoundsException(
                    "Índice " + indice + " fuera de rango (tamaño: " + size + ")");
        }

        Nodo<T> current = head;

        for (int i = 0; i < indice; i++) {
            current = current.next;
        }
        return current.data;
    }

    /**
     * Indica si la lista está vacía.
     *
     * @return {@code true} si la lista está vacía
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Devuelve la cantidad de elementos en la lista.
     *
     * @return número de elementos
     */
    public int getSize() {
        return size;
    }

    /**
     * Devuelve una representación en texto de todos los elementos, en orden.
     *
     * @return cadena con los elementos separados por " -> "
     */
    @Override
    public String toString() {
        if (isEmpty()) return "[vacía]";

        StringBuilder sb = new StringBuilder();
        Nodo<T> current = head;

        while (current != null) {
            sb.append(current.data);
            if (current.next != null)
                sb.append(" -> ");
            current = current.next;
        }
        
        return sb.toString();
    }
}