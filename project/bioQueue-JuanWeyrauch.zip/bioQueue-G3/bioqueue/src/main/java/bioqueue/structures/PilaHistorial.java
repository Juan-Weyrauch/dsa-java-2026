package bioqueue.structures;

import java.util.NoSuchElementException;

/**
 * Pila (stack) genérica implementada desde cero sobre una lista enlazada.s
 *
 * <p>
 * Se usa para registrar el historial de trasplantes realizados.
 * El último trasplante realizado es el primero en recuperarse (LIFO).
 * </p>
 *
 * @param <T> tipo de los elementos almacenados en la pila
 */
public class PilaHistorial<T> {
    /** Nodo en el tope de la pila. */
    private Nodo<T> top; // si quieren cambien el nombre, no se que ponerle. (seria el ultimo
                         // transplante.)

    /** Cantidad de elementos en la pila. */
    private int size; // no pienso poner 'tamanio' ni nada de esto, thxs.

    /**
     * Crea una pila vacía.
     */
    public PilaHistorial() {
        top = null;
        size = 0;
    }

    /**
     * Apila un elemento en el tope.
     *
     * @param dato el elemento a apilar; no puede ser {@code null}
     * @throws IllegalArgumentException si el dato es {@code null}
     */
    public void push(T dato) {
        if (dato == null)
            throw new IllegalArgumentException("El dato no puede ser null");
        Nodo<T> newNode = new Nodo<>(dato);
        newNode.next = top;
        top = newNode;
        size++;
    }

    /**
     * Retira y devuelve el elemento en el tope de la pila.
     *
     * @return el elemento removido
     * @throws NoSuchElementException si la pila está vacía
     */
    public T pop() {
        if (isEmpty())
            throw new NoSuchElementException("La pila está vacía.");
        T poppedDato = top.data;
        top = top.next;
        size--;
        return poppedDato;
    }

    /**
     * Devuelve el elemento en el tope sin retirarlo.
     *
     * @return el elemento en el tope
     * @throws NoSuchElementException si la pila está vacía
     */
    public T peek() {
        if (isEmpty())
            throw new java.util.NoSuchElementException("La pila está vacía");
        return top.data;
    }

    /**
     * Indica si la pila no contiene elementos.
     *
     * @return {@code true} si la pila está vacía
     */
    public boolean isEmpty() {
        return top == null;
    }

    /**
     * Devuelve la cantidad de elementos en la pila.
     *
     * @return número de elementos
     */
    public int getSize() {
        return size;
    }

    /**
     * Devuelve una representación del historial desde el más reciente al más
     * antiguo.
     *
     * @return cadena con todos los elementos de la pila
     */
    @Override
    public String toString() {
        return "deamn, comlete this class dudeee";
    }
}
