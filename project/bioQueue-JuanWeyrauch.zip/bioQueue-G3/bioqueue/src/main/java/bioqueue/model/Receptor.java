package bioqueue.model;

import java.time.LocalDateTime;

/**
 * Representa a un receptor de organos con sus datos de prioridad y registro.
 */
public class Receptor implements Comparable<Receptor> {

    private String cedula;
    private String nombre;
    private TipoOrgano tipoOrganoNecesitado;
    private TipoSangre tipoSangre;
    private int puntajePrioridad;
    private LocalDateTime fechaRegistro; // Para desempate FIFO

    /**
     * Crea un nuevo receptor y registra automaticamente su fecha de ingreso.
     *
     * @param cedula identificacion unica del receptor
     * @param nombre nombre del receptor
     * @param tipoOrganoNecesitado tipo de organo requerido por el receptor
     * @param tipoSangre tipo de sangre del receptor
     * @param puntajePrioridad puntaje de prioridad para asignacion
     */
    public Receptor(String cedula, String nombre, TipoOrgano tipoOrganoNecesitado,
                    TipoSangre tipoSangre, int puntajePrioridad) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.tipoOrganoNecesitado = tipoOrganoNecesitado;
        this.tipoSangre = tipoSangre;
        this.puntajePrioridad = puntajePrioridad;
        this.fechaRegistro = LocalDateTime.now(); // Se asigna automáticamente
    }

    /**
     * Obtiene la cedula del receptor.
     *
     * @return cedula del receptor
     */
    public String getCedula() { return cedula; }

    /**
     * Obtiene el nombre del receptor.
     *
     * @return nombre del receptor
     */
    public String getNombre() { return nombre; }

    /**
     * Obtiene el tipo de organo que necesita el receptor.
     *
     * @return tipo de organo necesitado
     */
    public TipoOrgano getTipoOrganoNecesitado() { return tipoOrganoNecesitado; }

    /**
     * Obtiene el tipo de sangre del receptor.
     *
     * @return tipo de sangre del receptor
     */
    public TipoSangre getTipoSangre() { return tipoSangre; }

    /**
     * Obtiene el puntaje de prioridad del receptor.
     *
     * @return puntaje de prioridad
     */
    public int getPuntajePrioridad() { return puntajePrioridad; }

    /**
     * Obtiene la fecha y hora de registro del receptor.
     *
     * @return fecha de registro
     */
    public LocalDateTime getFechaRegistro() { return fechaRegistro; }

    /**
     * Devuelve una representacion en texto del receptor.
     *
     * @return cadena con los datos principales del receptor
     */
    @Override
    public String toString() {
        return "Receptor{cedula='" + cedula + "', nombre='" + nombre +
               "', organo=" + tipoOrganoNecesitado + ", sangre=" + tipoSangre +
               ", prioridad=" + puntajePrioridad + "}";
    }

    @Override
    public int compareTo(Receptor otroReceptor) {
        if(otroReceptor.puntajePrioridad != this.puntajePrioridad){
        return Integer.compare(otroReceptor.puntajePrioridad, this.puntajePrioridad);
        }
        return this.fechaRegistro.compareTo(otroReceptor.fechaRegistro);
    }
}