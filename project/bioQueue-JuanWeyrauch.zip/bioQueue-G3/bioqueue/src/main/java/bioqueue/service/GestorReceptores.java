package bioqueue.service;

import bioqueue.model.Receptor;
import bioqueue.model.TipoOrgano;

import java.util.LinkedList;

/**
 * Servicio que gestiona el registro y consulta de receptores en lista de espera.
 */
public class GestorReceptores {

    /** Lista de espera priorizada, siempre ordenada por prioridad descendente. */
    private final LinkedList<Receptor> listaEspera;

    /**
     * Crea un gestor con la lista de espera vacía.
     */
    public GestorReceptores() {
        this.listaEspera = new LinkedList<>();
    }

    /** Registra un receptor en la lista de espera en la posición correcta según su prioridad. */
    public void registrar(Receptor nuevo) {
        if (nuevo == null) return;
        int index = 0;
        while (index < listaEspera.size() && nuevo.compareTo(listaEspera.get(index)) > 0) {
            index++;
        }
        listaEspera.add(index, nuevo);
    }

    /** Elimina un receptor de la lista de espera por su cédula. */
    public Receptor eliminarPorCedula(String cedula) {
        Receptor encontrado = buscarPorCedula(cedula);
        if (encontrado != null) {
            listaEspera.remove(encontrado);
        }
        return encontrado;
    }

    /** Busca un receptor por su cédula. */
    public Receptor buscarPorCedula(String cedula) {
        for (Receptor unReceptor : listaEspera) {
            if (unReceptor.getCedula().equals(cedula)) {
                return unReceptor;
            }
        }
        return null;
    }

    /** Devuelve la lista de espera completa, en orden de prioridad. */
    public LinkedList<Receptor> getListaEspera() {
        return new LinkedList<>(listaEspera);
    }

    /** Imprime por consola todos los receptores en orden de prioridad. */
    public void listarTodos() {
        for(Receptor unReceptor : listaEspera){
            System.out.println(unReceptor.toString());
        }
    }


}