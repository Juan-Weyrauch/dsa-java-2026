# bioQueue-G3
BioQueue - Simulador de gestión de listas de espera para trasplantes de órganos | Proyecto UCU - Algoritmos y Estructuras de Datos
