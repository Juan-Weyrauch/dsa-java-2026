package ucu.edu.aed.modelo;

/**
 * Representa una tarea operativa que recibe la nave para ser procesada.
 *
 * <p><strong>TODO (alumno):</strong> completar esta clase según el enunciado del parcial.
 *
 * <p>Recordá que el enunciado define los atributos de una tarea:
 * <ul>
 *   <li>ID único.</li>
 *   <li>Descripción.</li>
 *   <li>Nivel de criticidad (1 a 4, siendo 1 el más crítico).</li>
 * </ul>
 *
 * <p>Sugerencias:
 * <ul>
 *   <li>Para poder usar la tarea como dato del árbol AVL provisto, la clase debería
 *       implementar {@link Comparable Comparable&lt;Tarea&gt;}.</li>
 *   <li>Considerá si la clase debe ser inmutable (campos {@code final}, sin setters).</li>
 *   <li>Considerá qué validaciones aplican al construir una tarea.</li>
 * </ul>
 */
public class Tarea {

    // TODO: definir atributos.

    // TODO: definir constructor(es) y validaciones.

    // TODO: definir getters relevantes.

    // TODO: implementar Comparable<Tarea> si corresponde.

    // TODO: opcionalmente, sobrescribir equals / hashCode / toString.
}
